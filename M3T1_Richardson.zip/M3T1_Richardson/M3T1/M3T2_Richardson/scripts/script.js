var randomBodyParts = ["Fingers", "Knees", "Eyebrows", "Toes", "Foot"];
         var randomAdjectives = ["Smelly", "Ugly", "Dank", "Mellow"];
         var randomWords = ["Fly", "Marmot", "Stick", "Monkey", "Rat"];

         // Pick a random body part from randomBodyParts array:
         var randomBodyPart = randomBodyParts[Math.floor(Math.random() * 5)];
         // Pick a Random word from the randomAdjectives array:
         var randomAdjective = randomAdjectives[Math.floor(Math.random() * 4)];
         // Pick a random word from the randomWords array:
         var randomWord = randomWords[Math.floor(Math.random() * 5)];
         // Join all the random strings into a sentence:
         var randomInsult = " Your " + randomBodyPart + " is like a  " +   
		 randomAdjective  + " " + randomWord + " !!! ";
		
		 document.write(randomInsult);