This is the version of the Hangman for m3hw

() first version uses chapter 7.