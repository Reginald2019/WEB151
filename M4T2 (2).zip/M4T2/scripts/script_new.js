
//script_new.js

var clickHandler = function (event) {
	console.log("Click!");
	g = window.game
	g.score = g.score +1 + g.interns;
	//$("#score").text(g.score);
	//console.log(g.score);
};

var hireInterns = function (event) {
	g = window.game;
	// interns cost 10 to start
	// each one after that cost double 
	
	
	if (g.score >= g.internCost) {
		g.score = g.score - g.internCost;
		g.interns = g.interns + 1 ;
		g.internCost == 10 +  g.interns * 1.1;
	}
	console.log("interns = " + g.interns);
	console.log("Cost per Intern = " + g.internCost);
	$("#interns").text(g.interns);
	$("#internCost").text(g.internCost.toFixed(2) );
};

var buyBotFarms = function (event) {
	// first bot farm is 100
	// each increases by 1.2x
	console.log
	
	g = window.game;
	
	if (g.score >= g.botFarmCost) {
		g.score = g.score - g.botFarmCost;
		g.botFarms = g.botFarms + 1;
		g.botFarmCost = g.botFarmCost * 1.2;
		//$("score").text(g.score);
	};
	$("#botFarms").text(g.botFarms);
	$("#botFarmCost").text(g.botFarmCost.toFixed(2) );
};

var updateScore = function (event) {
	g = window.game;
	console.log(g.score)
	// every second, bot farms click for you
	// (which also means you get intern clicks)
	// left alone, the interns get 10 cent each.
	
	//Balance this 
	clicksPerSecond = g.botFarms * g.interns
	clicksPerSecond += g.interns * 0.10; // 10 cents per second 
	clicksPerFrame = clicksPerSecond / 30;
	
	g.score = g.score + g.botFarms;
	$("#score").text(g.score.toFixed(2) ); // dollars to cents

};
	
// set starting score
//var score = 0;
//$("#score").text(score);

//set the click handler
//$("#clickme").click(clickHandler);

//create game object
this.game = {
	name: 'Clicker Game',
	score: 0,
	interns: 0,
	internCost: 10,
	botFarms: 0,
	botFarmCost: 100,
};


//set starting score 

this.game.score = 0;
$("#score").text(this.game.score);

//set auto clickers 
$("#interns").text(this.game.interns);

//set the click handler
$("#clickme").click(clickHandler);

$("#hireInterns").click(hireInterns);

$("#buyBotFarms").click(buyBotFarms);

//console.log("This = " + this);

setInterval(updateScore, 100);





