
//script_new.js

var clickHandler = function (event) {
	console.log("Click!");
	g = window.game
	g.score = g.score +1 + g.interns;
	$("#score").text(g.score);
	console.log(g.score);
};

var hireInterns = function (event) {
	g = window.game;
	// interns cost $$$
	internCost = 10 +  g.interns;
	if (g.score >= internCost) {
		g.score = g.score - internCost;
		g.interns = g.interns +1 ;
	}
	console.log("interns = " + g.interns);
	console.log("Cost per Intern = " + internCost);
	$("#interns").text(g.interns);
};

// set starting score
//var score = 0;
//$("#score").text(score);

//set the click handler
//$("#clickme").click(clickHandler);

//create game object
this.game = {
	name: 'Clicker Game',
	score: 0,
	interns: 0,
};


//set starting score 

this.game.score = 0;
$("#score").text(this.game.score);

//set auto clickers 
$("#interns").text(this.game.interns);

//set the click handler
$("#clickme").click(clickHandler);

$("#hireInterns").click(hireInterns);

//console.log("This = " + this);





