//Choosing word array
/*
		var words = [
		   "windex", 
		   "superlongword",
		   "pancake",
		   "waffle",
		   "loooooooooooooongword",
		   "manifest"
		   
		];
		
		var word = words[Math.floor(Math.random() * words.length)];
		//Choosing answer array
		var answerArray = [];
		for (var i = 0; i < word.length; i++) 
		 {answerArray[i] = "_";
		}
		var remainingLetters = word.length;
		//Game loop
		count = 0;
		while (remainingLetters > 0) {
		// Game code 
		// Show Player Progress
		// Take player input
		// Update answerArray and remainingLetters for every correct guess
		//Player Progress
		  alert(answerArray.join(" "));
		  document.write("<p> atttempt # " + count + answerArray.join(" ")+ "</p>");
		  count++;
		//Handle PLayer Input
		  var guess = prompt("Guess a letter, or click cancel to stop playing");
		  if (guess === null){
		     break;
		   } else if (guess.length !==1){
		     alert("please enter a single letter");
		   } else {
		     // Update the game stat with the guess
		     // Update Game Stat
		     for (var j = 0; j < word.length; j++) {
		      if(word[j] === guess) {
		       answerArray[j] = guess;
			   remainingLetters--;
			  }
			 }
		}
		// End Game 
		}
		alert(answerArray.join(""));
		alert("Good Job! The answer was" + word);
		*/
// End of Old code
// New Code 
count = 0;
var pickWord = function() {
	var words = [
		   "windex", 
		   "superlongword",
		   "pancake",
		   "waffle",
		   "loooooooooooooongword",
		   "manifest"
		   
		];
	var word = words[Math.floor(Math.random() * words.length)];
	
	return word;
};

var setupAnswerArray = function(word){
var answerArray = [];
	for (var i = 0; i < word.length; i++) 
		 {answerArray[i] = "_";
		};
		
		return answerArray
};

var showPlayerProgress = function(answerArray){
	alert(answerArray.join(" "));
		  document.write("<p> attempt # " + count + answerArray.join(" ")+ "</p>");
		  count++;
}
var getGuess = function(){
	var guess = prompt("Guess a letter, or click cancel to stop playing");
		  if (guess.length !== 1){
			  alert('Please enter a single letter');
		    
		   }
	return guess;
}
var updateGameState = function(guess, word, answerArray){
	var correctGuess = 0;
	for (var j = 0; j < word.length; j++) {
		      if(word[j] === guess) {
		       answerArray[j] = guess;
			   //remainingLetters--;
			   correctGuess++;
			  }
			 }
			 return correctGuess;
};
var showAnswerandCongratulatePlayer = function(answerArray){
	alert(answerArray.join(""));
		alert("Good Job! The answer was" + word);
}
// End of new code 

//Newer code

var word = pickWord();
var answerArray = setupAnswerArray(word);
var remainingLetters = word.length;

while (remainingLetters > 0){
	showPlayerProgress(answerArray);
	var guess = getGuess();
	if (guess === null) {
		break;
		
	} 
	else if (guess.length !==1){
		alert("Please enter a single letter.");
	} 
	else {
		var correctGuess = updateGameState(guess, word, answerArray);
		remainingLetters -= correctGuess;
	}
}

showAnswerandCongratulatePlayer(answerArray);
		
		
	
