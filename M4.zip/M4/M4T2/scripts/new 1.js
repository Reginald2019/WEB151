
//script.js
// clicker app

var updateScore = function(score){
	var scoreElement = document.getElementById("score");
	scoreElement(scoreElement.innerHTML) = score;
	console.log("score is now" + score);
}

//select an item from the page
var h1 = document.getElementById("main-heading");
console.log(h1.innerHTML);

//let's update the score a few times 
updateScore(1);
updateScore(2);
updateScore(3);

var newHeadingText = prompt("new Heading:");
$("#main-heading").text(newHeadingText);

$("#score").text(100);
